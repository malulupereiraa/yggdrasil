# Good Boy License

We’ve released the icon pack under either MIT or the [Good Boy License](http://icons8.com/good-boy-license/). We invented it. Please do _whatever your mom would approve of:_

## Permitted Use

* Download in any format
* Change
* Fork

## Prohibited Use

* No tattoos
* No touching with unwashed hands
* No exchanging for drugs.
