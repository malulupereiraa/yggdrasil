# Changelog

All notable changes to this project will be documented in this file.

## 1.3.0 - 2019-11-21

### Added

- SCSS library. See it as an experimental feature and feel free to report bugs and to suggest new features. 
- SVG files. Earlier they were reachable only from the [site]('https://icons8.com/line-awesome/').
- NPM package is updated with scss and svgs as well.

### Fixed

- Github and site versions are now synchronized.